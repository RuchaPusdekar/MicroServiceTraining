package com.tcs.accountmicroservice.model;
import lombok.Data;

@Data

public class AccountInput {

	private long accountId;
	private double amount;
}
