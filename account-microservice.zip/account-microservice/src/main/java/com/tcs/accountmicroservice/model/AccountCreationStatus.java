package com.tcs.accountmicroservice.model;

import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountCreationStatus {

	
	@Id
	private long accountId;
	private String message;
}
