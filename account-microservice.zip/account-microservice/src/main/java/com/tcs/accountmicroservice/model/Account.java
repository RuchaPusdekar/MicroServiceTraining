package com.tcs.accountmicroservice.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="act_tbl")
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private long accountId;
	private double currentBalance;
	private String accountType;
	private String ownerName;
	private String customerId;
	
}
