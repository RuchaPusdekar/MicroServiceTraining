package com.tcs.accountmicroservice.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;


@Data
@Entity
public class Statement {

	@Id
	private String date;
	private double Withdrawal;
	private double Deposit;
	private double ClosingBalance;
	
}
