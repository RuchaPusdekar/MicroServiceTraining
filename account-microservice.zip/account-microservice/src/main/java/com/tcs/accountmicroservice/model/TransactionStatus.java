package com.tcs.accountmicroservice.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class TransactionStatus {

	@Id
	private int id;
	private String message;
	private long source_balance;
	private long destination_balance;
	
}
