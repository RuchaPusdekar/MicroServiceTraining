package com.tcs.accountmicroservice.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.tcs.accountmicroservice.model.Account;

public interface AccountRepository extends JpaRepository<Account,Long> {


	Account findByAccountId(long accountId);
	
	List<Account> findByCustomerId(String customerId);
}
