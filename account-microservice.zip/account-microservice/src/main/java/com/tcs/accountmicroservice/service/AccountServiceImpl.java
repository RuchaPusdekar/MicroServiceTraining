package com.tcs.accountmicroservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.accountmicroservice.model.Account;
import com.tcs.accountmicroservice.model.AccountCreationStatus;
import com.tcs.accountmicroservice.model.AccountInput;
import com.tcs.accountmicroservice.repo.AccountRepository;


@Service
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountRepository accountRepository;
	
	@Override
	public AccountCreationStatus createAccount( Account account) {
		// TODO Auto-generated method stub
		accountRepository.save(account);
		AccountCreationStatus accountCreationStatus = new AccountCreationStatus(account.getAccountId(),
				"Sucessfully Created");
		System.out.println("Account Created Sucessfully");
		return accountCreationStatus;
	}

	@Override
	public Account getAccount(long accountId) {
		// TODO Auto-generated method stub
		Account account = accountRepository.findByAccountId(accountId);
		if (account == null) {
			System.out.println("Account Does Not Exist");
		}
		return account;
	}

	@Override
	public Account updateDepositBalance(AccountInput accountInput) {
		// TODO Auto-generated method stub
		Account toUpdateAcc = accountRepository.findByAccountId(accountInput.getAccountId());
		toUpdateAcc.setCurrentBalance(toUpdateAcc.getCurrentBalance() + accountInput.getAmount());
		return accountRepository.save(toUpdateAcc);
	}

	@Override
	public Account updateBalance(AccountInput accountInput) {
		// TODO Auto-generated method stub
		Account toUpdateAcc = accountRepository.findByAccountId(accountInput.getAccountId());
		toUpdateAcc.setCurrentBalance(toUpdateAcc.getCurrentBalance() - accountInput.getAmount());
		return accountRepository.save(toUpdateAcc);
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		try {
			return accountRepository.findAll();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return new ArrayList<>();
	}

	public List<Account> getCustomerAccounts( String customerId) {
		List<Account> accountList = accountRepository.findByCustomerId(customerId);
		return accountList;
	}
	
}
