package com.tcs.accountmicroservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.accountmicroservice.model.Account;
import com.tcs.accountmicroservice.model.AccountCreationStatus;
import com.tcs.accountmicroservice.model.AccountInput;
import com.tcs.accountmicroservice.service.AccountService;

@RestController
@RequestMapping("api/v1/acc")
public class AccountController {

	
	@Autowired
	
	AccountService accountservice;
	
	@GetMapping("/getAccount/{accountId}")
	public Account getAccount(@PathVariable long accountId){		
			Account act =accountservice.getAccount(accountId);
			return act;
	}
	
	@PostMapping("/createAccount")	
	public AccountCreationStatus createAccount(@RequestBody Account account) {

		AccountCreationStatus returnObjAccountCreationStatus = accountservice.createAccount( account);

		if (returnObjAccountCreationStatus == null)
			System.out.println("Customer Creation Unsucessful");
		else
			System.out.println("Account Created Sucessfully");

		return returnObjAccountCreationStatus;
	}
	
	@GetMapping("/find")
	public List<Account> getAllAccounts(){
		List<Account> account = accountservice.getAllAccounts();
		return account;
	}

	@PostMapping("/deposit")
	public Account updateDepositBalance(@RequestBody AccountInput accInput){
		Account newUpdateAccBal = accountservice.updateDepositBalance(accInput);
		System.out.println("amount deposited");
		return newUpdateAccBal;
	}
	
	@PostMapping("/withdraw")
	public Account updateBalance(@RequestBody AccountInput accInput){
		Account newUpdateAccBal = accountservice.updateBalance(accInput);
		System.out.println("amount withdraw sucessful");
		return newUpdateAccBal;
	}
	
	@GetMapping("/getAccounts/{customerId}")
	public List<Account> getCustomerAccounts(@PathVariable String customerId){
		System.out.println("Account List Returned");
		return accountservice.getCustomerAccounts(customerId);
	}
	
}
