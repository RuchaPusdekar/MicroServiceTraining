package com.tcs.accountmicroservice.service;

import java.util.List;

import com.tcs.accountmicroservice.model.Account;
import com.tcs.accountmicroservice.model.AccountCreationStatus;
import com.tcs.accountmicroservice.model.AccountInput;

public interface AccountService {

	public AccountCreationStatus createAccount( Account account);
	
	public Account getAccount(long accountId);
	
	public Account updateDepositBalance(AccountInput accountInput);

	public Account updateBalance(AccountInput accountInput);
	
	public List<Account> getAllAccounts();
	
	public List<Account> getCustomerAccounts(String customerId); 
	
}
