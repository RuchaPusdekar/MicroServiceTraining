package com.tcs.onlineapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
