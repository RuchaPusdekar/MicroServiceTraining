package com.tcs.onlineapplication.service;

import com.tcs.onlineapplication.entity.Cart;

public interface CartService {

	public Cart getCart(int id);

	public void addCart(Cart cart);

	public void editCart(int id, Cart cart);

	public void deleteCart(int id);

}