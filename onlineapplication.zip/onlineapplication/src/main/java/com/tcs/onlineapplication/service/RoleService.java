package com.tcs.onlineapplication.service;

import java.util.List;

import com.tcs.onlineapplication.entity.Role;

public interface RoleService {
	
	public List<Role> getRoles();

	public Role getRole(int id);

	public void addRole(Role role);

	public void editRole(int id, Role role);

	public void deleteRole(int id);

}