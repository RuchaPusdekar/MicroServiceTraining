package com.tcs.webservice.controller;

import java.util.ArrayList;



import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.tcs.webservice.entity.Employee;

@RestController

public class MyController {
	
	@RequestMapping("/welcome")
	public String welcome() {
		return "welcome to spring boot";
	}
	
	@RequestMapping("/hello")
	public String hello() {
		return "this is from hello";
	}

	@GetMapping("/user/{arg}")
	public String display(@PathVariable String  arg) {
		return "welcome "+arg+" to spring boot";
	}
	
//	@GetMapping("/user?name={value}")
//	public String show(@PathParam(value ="name")String name) {
//		return "welcome "+name+" to spring boot";
//	} 
	
	@GetMapping("/employee")
	public Employee getEmployee() {
	  return new Employee(100,"test","test@gmail.com");
	}
	
	
	@GetMapping("/employees")
	public java.util.List<Employee> getEmployees(){
		java.util.List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(new Employee(101,"test","test@gmail.com"));
		employeeList.add(new Employee(102,"test2","test2@gmail.com"));
		employeeList.add(new Employee(103,"test23","test23@gmail.com"));
		return employeeList;
	}
	
}
	
	
	