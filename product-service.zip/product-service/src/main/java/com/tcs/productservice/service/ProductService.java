package com.tcs.productservice.service;

import java.util.List;
import com.tcs.productservice.entity.Product;

public interface ProductService {

	
	public void deleteProduct(int id);
	public void addProduct (Product product);
	public void editProduct (int id,Product product);
	public Product getProduct(int id);
	public List<Product> getProducts();
	
	
	
	
}

