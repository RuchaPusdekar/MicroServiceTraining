package com.tcs.productservice.entity;


import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Product {
	
	@Id
	//@Generated()
    private int id ;
    private String name;
    private float unitprice;
    private int stock;
    
    
    
    
}
