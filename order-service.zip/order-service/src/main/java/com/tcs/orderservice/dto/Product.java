package com.tcs.orderservice.dto;

import lombok.Data;

@Data
public class Product {

	private int id;
	private String name;
	private float unitPrice;
	
	
	
}
