package com.tcs.orderservice.service;

import java.util.List;

import com.tcs.orderservice.entity.Order;

public interface OrderService {

	public List<Order> findAll();
	
	public Order findById(int id);
	
	public Order save(Order order);
	
	public void update(int id,Order order);
	
	public void deleteById(int id);
	
	public List<Order> findByCartId(int cartId);
	
}
