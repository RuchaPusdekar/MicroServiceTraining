package com.tcs.orderservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.orderservice.entity.Order;
import com.tcs.orderservice.repo.OrderRepository;


@Service
public class OrderServiceImpl implements OrderService {

	
	@Autowired
	OrderRepository orderRepository;
	
	
	public List<Order> findAll() {
		// TODO Auto-generated method stub
		return orderRepository.findAll();
	}

	@Override
	public Order findById(int id) {
		// TODO Auto-generated method stub
		return orderRepository.findById(id).get();
	}

	@Override
	public Order save(Order order) {
		// TODO Auto-generated method stub
		return orderRepository.save(order);
	}

	@Override
	public void update(int id, Order order) {
		// TODO Auto-generated method stub
		orderRepository.save(order);

	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		orderRepository.deleteById(id);

	}

	@Override
	public List<Order> findByCartId(int cartId) {
		// TODO Auto-generated method stub
		return orderRepository.findByCartId(cartId);
	}

}
