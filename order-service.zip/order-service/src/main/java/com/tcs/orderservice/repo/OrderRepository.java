package com.tcs.orderservice.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tcs.orderservice.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {
	
	public List<Order> findByCartId(int cartId);

}
