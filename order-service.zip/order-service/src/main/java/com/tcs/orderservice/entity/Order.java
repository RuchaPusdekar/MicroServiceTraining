package com.tcs.orderservice.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.tcs.orderservice.dto.Product;
import com.tcs.orderservice.service.OrderService;

import lombok.Data;


@Entity
@Data
@Table(name="tbl_order")
public class Order {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int cartId;
	private int productId;
	private String address;
	private String paymentMethod;
	private float totalPrice;
	
	@Autowired
	OrderService orderService;
	
	@Autowired
	RestTemplate restTemplate;
	
	public void updateTotalPrice(int id) {
		Order ord =orderService.findById(id);
		int productId=ord.getProductId();
	
		Product pdt= restTemplate.getForObject("http://product-service:8085/api/v1/products/"+productId,Product.class);
		float price=pdt.getUnitPrice();
		ord.setTotalPrice(price);
		orderService.update(id, ord);
	
	}
	
	
	
}
